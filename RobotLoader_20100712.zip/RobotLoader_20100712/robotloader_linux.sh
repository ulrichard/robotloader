#!/bin/bash
#

java -Djava.library.path="./lib" -jar RobotLoader_lib.jar
